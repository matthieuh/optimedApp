$(document).on("mobileinit", function(){
	// Page
    $.mobile.page.prototype.options.headerTheme = "a";
    $.mobile.page.prototype.options.contentTheme = "a";
    $.mobile.page.prototype.options.footerTheme = "a"
});

